// 使用anime.js的全局变量
// import { animate, stagger } from './anime.min.js';

// 全局变量
const videoUrl = document.getElementById('video-url');
const parseBtn = document.getElementById('parse-btn');
const clearBtn = document.getElementById('clear-btn');
const clearInputBtn = document.getElementById('clear-input-btn');
const parseSource = document.getElementById('parse-source');
const videoPlayer = document.getElementById('video-player');
const player = document.getElementById('player');
const videoPlaceholder = document.getElementById('video-placeholder');
const loader = document.getElementById('loader');
const toast = document.getElementById('toast');
// anime.js的简写方法
const animate = anime;
const stagger = anime.stagger;

// 添加视频窗口提示元素
let videoCenterMessage;
// 当前选中的解析源
let currentSource = 'auto';
// 当前正在使用的解析源索引（用于自动切换）
let currentSourceIndex = -1;
// 保存用户输入的视频URL
let currentVideoUrl = '';
// 记录是否正在自动切换解析源
let isAutoSwitching = false;

// 解析源列表
const parseSources = [
    { id: 'auto', name: '自动匹配', url: '' },
    { id: 'playerjy', name: '解析源1', url: 'https://jx.playerjy.com/?url=' },
    { id: 'aidouer', name: '解析源2', url: 'https://jx.aidouer.net/?url=' },
    { id: 'm3u8tv', name: '解析源3', url: 'https://jx.m3u8.tv/jiexi/?url=' },
    { id: 'xmflv', name: '解析源4', url: 'https://jx.xmflv.com/?url=' },
    { id: 'okjx', name: '解析源5', url: 'https://okjx.cc/?url=' },
    { id: '8090g', name: '解析源6', url: 'https://www.8090g.cn/?url=' }
];

// 初始化
document.addEventListener('DOMContentLoaded', () => {
    initAnimation();
    initEvents();
    initParseSourceOptions();
    initCenterMessage();
    preloadIcons(); // 预加载所有图标
});

// 预加载图标确保显示 - 使用网站原始图标
function preloadIcons() {
    // 使用各网站官方favicon图标
    const iconMapping = {
        'qq': 'https://v.qq.com/favicon.ico',
        'iqiyi': 'https://www.iqiyi.com/favicon.ico',
        'youku': 'https://img.alicdn.com/tfs/TB1WeJ9Xrj1gK0jSZFuXXcrHpXa-195-195.png',
        'bilibili': 'https://www.bilibili.com/favicon.ico',
        'mgtv': 'https://www.mgtv.com/favicon.ico'
    };
    
    // 查找并处理所有网站图标
    document.querySelectorAll('.site-icon').forEach(icon => {
        // 获取图标对应的网站类名
        const className = Array.from(icon.classList)
            .find(cls => iconMapping[cls]);
        
        if (className && iconMapping[className]) {
            // 强制设置背景图片
            icon.style.backgroundImage = `url('${iconMapping[className]}')`;
            icon.style.backgroundSize = 'contain';
            icon.style.backgroundRepeat = 'no-repeat';
            icon.style.backgroundPosition = 'center';
            icon.style.backgroundColor = '#fff';
            
            // 预加载图片
            const img = new Image();
            img.src = iconMapping[className];
            img.onload = () => console.log(`图标预加载成功: ${className}`);
        }
    });
}

// 初始化动画效果
function initAnimation() {
    // 标题动画
    animate('.title', {
        opacity: [0, 1],
        translateY: [50, 0],
        duration: 1200,
        easing: 'easeOutExpo'
    });

    // 播放器容器动画
    animate('.player-container', {
        opacity: [0, 1],
        translateY: [30, 0],
        duration: 1000,
        delay: 300,
        easing: 'easeOutQuint'
    });

    // 输入区域动画
    animate('.input-area', {
        opacity: [0, 1],
        translateY: [30, 0],
        duration: 1000,
        delay: 500,
        easing: 'easeOutQuint'
    });

    // 网站入口容器动画
    animate('.site-entrances', {
        opacity: [0, 1],
        translateY: [30, 0],
        duration: 1000,
        delay: 700,
        easing: 'easeOutQuint'
    });

    // 不再加载网站图标的动画效果
}

// 初始化事件监听
function initEvents() {
    // 解析按钮点击事件
    parseBtn.addEventListener('click', parseVideo);
    
    // 输入框内的清除按钮点击事件
    clearBtn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        videoUrl.value = '';
        clearBtn.style.display = 'none';
        videoUrl.focus();
    });
    
    // 新增的独立清除按钮点击事件
    clearInputBtn.addEventListener('click', (e) => {
        videoUrl.value = '';
        clearBtn.style.display = 'none';
        videoUrl.focus();
        
        // 添加按钮点击动画效果
        animate(clearInputBtn, {
            scale: [1, 0.9, 1],
            duration: 300,
            easing: 'easeOutElastic(1, .6)'
        });
    });
    
    // 输入框内容变化，控制清除按钮显示
    videoUrl.addEventListener('input', () => {
        clearBtn.style.display = videoUrl.value ? 'block' : 'none';
    });
    
    // 输入框获得焦点时检查是否显示清除按钮
    videoUrl.addEventListener('focus', () => {
        clearBtn.style.display = videoUrl.value ? 'block' : 'none';
    });
    
    // 页面加载后立即检查输入框是否有内容
    setTimeout(() => {
        clearBtn.style.display = videoUrl.value ? 'block' : 'none';
    }, 300);
    
    // 回车键解析
    videoUrl.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            parseVideo();
        }
    });
    
    // 移除网站图标的所有动画效果，使用简单的CSS悬停效果
    
    // 解析按钮悬浮效果
    parseBtn.addEventListener('mouseenter', () => {
        animate(parseBtn, {
            backgroundColor: 'rgb(46, 204, 113)',
            duration: 300,
            easing: 'easeOutQuad'
        });
    });
    
    parseBtn.addEventListener('mouseleave', () => {
        animate(parseBtn, {
            backgroundColor: '#3498db',
            duration: 300,
            easing: 'easeOutQuad'
        });
    });
}

// 初始化解析源下拉框
function initParseSourceOptions() {
    // 清空已有选项
    parseSource.innerHTML = '';
    
    // 添加解析源选项
    parseSources.forEach(source => {
        const option = document.createElement('option');
        option.value = source.id;
        option.textContent = source.name; // 使用name作为显示文本而不是id
        parseSource.appendChild(option);
    });
    
    // 默认选择自动匹配
    parseSource.value = 'auto';
}

// 初始化视频中心提示信息元素
function initCenterMessage() {
    videoCenterMessage = document.createElement('div');
    videoCenterMessage.className = 'video-center-message';
    videoCenterMessage.style.display = 'none';
    videoCenterMessage.style.position = 'absolute';
    videoCenterMessage.style.top = '50%';
    videoCenterMessage.style.left = '50%';
    videoCenterMessage.style.transform = 'translate(-50%, -50%)';
    videoCenterMessage.style.backgroundColor = 'rgba(0, 0, 0, 0.85)';
    videoCenterMessage.style.color = 'white';
    videoCenterMessage.style.padding = '15px 20px';
    videoCenterMessage.style.borderRadius = '8px';
    videoCenterMessage.style.zIndex = '1002';
    videoCenterMessage.style.textAlign = 'center';
    videoCenterMessage.style.fontSize = '15px';
    videoCenterMessage.style.fontWeight = 'normal';
    videoCenterMessage.style.boxShadow = '0 4px 10px rgba(0, 0, 0, 0.3)';
    videoCenterMessage.style.minWidth = '200px';
    videoCenterMessage.style.maxWidth = '80%';
    
    // 添加到播放器容器中
    document.querySelector('.player-container').appendChild(videoCenterMessage);
    
    // 初始化时设置占位符提示文本
    videoPlaceholder.innerHTML = `
        <i class="bi bi-play-circle"></i>
        <p>请输入视频链接后点击解析按钮</p>
    `;
}

// 在视频播放窗口中显示提示信息 - 简化版本
function showVideoCenterMessage(message, duration = 3000, type = 'info') {
    // 如果正在显示，先隐藏之前的消息并重置缩放比例
    if (videoCenterMessage.style.display !== 'none') {
        videoCenterMessage.style.display = 'none';
        videoCenterMessage.style.opacity = '0';
        videoCenterMessage.style.transform = 'translate(-50%, -50%) scale(1)'; // 重置缩放
    }
    
    // 清空之前的内容
    videoCenterMessage.innerHTML = '';
    
    // 简化样式，仅使用基本颜色区分消息类型
    let backgroundColor, iconClass;
    switch(type) {
        case 'success':
            backgroundColor = 'rgba(39, 174, 96, 0.9)';
            iconClass = 'bi bi-check-circle';
            break;
        case 'error':
            backgroundColor = 'rgba(231, 76, 60, 0.9)';
            iconClass = 'bi bi-exclamation-circle';
            break;
        case 'warning':
            backgroundColor = 'rgba(241, 196, 15, 0.9)';
            iconClass = 'bi bi-exclamation-triangle';
            break;
        case 'loading':
            backgroundColor = 'rgba(41, 128, 185, 0.9)';
            iconClass = '';
            break;
        case 'info':
        default:
            backgroundColor = 'rgba(52, 73, 94, 0.9)';
            iconClass = 'bi bi-info-circle';
    }
    
    videoCenterMessage.style.backgroundColor = backgroundColor;
    
    // 仅在加载状态显示简单的加载动画
    if (type === 'loading') {
        const spinner = document.createElement('div');
        spinner.className = 'message-spinner';
        spinner.style.width = '22px';
        spinner.style.height = '22px';
        spinner.style.margin = '0 auto 12px auto';
        spinner.style.border = '3px solid rgba(255, 255, 255, 0.3)';
        spinner.style.borderRadius = '50%';
        spinner.style.borderTopColor = '#ffffff';
        spinner.style.animation = 'spin 1s ease-in-out infinite';
        videoCenterMessage.appendChild(spinner);
    } else if (iconClass) {
        // 为非加载状态添加图标
        const icon = document.createElement('i');
        icon.className = iconClass;
        icon.style.fontSize = '24px';
        icon.style.marginBottom = '10px';
        icon.style.display = 'block';
        videoCenterMessage.appendChild(icon);
    }
    
    // 简化进度显示，只在自动解析模式下显示纯文本进度
    if (message.includes('尝试解析源') && type === 'loading') {
        const sources = parseSources.filter(source => source.id !== 'auto');
        const totalSources = sources.length;
        const currentIndex = currentSourceIndex + 1;
        
        // 仅使用文本显示进度
        message = `${message} (${currentIndex}/${totalSources})`;
    }
    
    // 添加消息文本
    const textContainer = document.createElement('div');
    textContainer.textContent = message;
    textContainer.style.lineHeight = '1.5';
    videoCenterMessage.appendChild(textContainer);
    
    // 显示消息，使用简单的淡入效果
    videoCenterMessage.style.display = 'block';
    videoCenterMessage.style.opacity = '0';
    
    // 使用简单的CSS过渡而不是动画库
    videoCenterMessage.style.transition = 'opacity 0.3s ease-out';
    setTimeout(() => {
        videoCenterMessage.style.opacity = '1';
    }, 10);
    
    // 如果设置了持续时间，则在指定时间后隐藏
    if (duration !== 99999) {
        setTimeout(() => {
            videoCenterMessage.style.transition = 'opacity 0.3s ease-in';
            videoCenterMessage.style.opacity = '0';
            setTimeout(() => {
                videoCenterMessage.style.display = 'none';
            }, 300);
        }, duration);
    }
}

// 显示提示信息
function showToast(message, duration = 3000) {
    toast.textContent = message;
    toast.style.display = 'block';
    
    animate(toast, {
        opacity: [0, 1],
        translateY: [-20, 0],
        duration: 300,
        easing: 'easeOutCubic'
    });
    
    setTimeout(() => {
        animate(toast, {
            opacity: [1, 0],
            translateY: [0, -20],
            duration: 300,
            easing: 'easeOutCubic',
            complete: () => {
                toast.style.display = 'none';
            }
        });
    }, duration);
}

// 显示加载中
function showLoader() {
    loader.style.display = 'flex';
    animate(loader, {
        opacity: [0, 1],
        duration: 300,
        easing: 'easeOutCubic'
    });
}

// 隐藏加载中
function hideLoader() {
    animate(loader, {
        opacity: [1, 0],
        duration: 300,
        easing: 'easeOutCubic',
        complete: () => {
            loader.style.display = 'none';
        }
    });
}

/**
 * 自动测试解析源
 * @param {string} url 要解析的视频URL
 * @returns {Promise<string|null>} 返回可用的解析源URL或null
 */
async function autoTestSources(url) {
    showVideoCenterMessage('正在匹配解析源...', 99999, 'loading');
    
    // 使用预定义的解析源列表，过滤掉自动选项
    const sources = parseSources.filter(source => source.id !== 'auto');
    const totalSources = sources.length;
    
    // 创建一个用于测试的隐藏iframe
    const testFrame = document.createElement('iframe');
    testFrame.style.display = 'none';
    document.body.appendChild(testFrame);
    
    // 按顺序尝试每个解析源
    for (let i = 0; i < sources.length; i++) {
        const source = sources[i];
        const fullUrl = source.url + url;
        
        showVideoCenterMessage(`正在尝试解析源: ${source.name}`, 99999, 'loading');
        console.log(`尝试解析源 ${source.id}...`);
        
        try {
            // 使用Promise包装iframe加载过程
            const result = await new Promise((resolve, reject) => {
                // 设置超时
                const timeout = setTimeout(() => {
                    reject(new Error('解析超时'));
                }, 8000);
                
                // 加载解析URL
                testFrame.src = fullUrl;
                
                // 监听iframe加载完成事件
                testFrame.onload = () => {
                    clearTimeout(timeout);
                    
                    try {
                        // 尝试检测iframe是否有内容加载
                        if (testFrame.contentWindow && 
                            testFrame.contentWindow.document && 
                            testFrame.contentWindow.document.body) {
                            resolve(true);
                        } else {
                            reject(new Error('无法访问iframe内容'));
                        }
                    } catch (e) {
                        // 跨域错误，但可能仍然是成功的
                        // 大多数解析服务会有跨域限制，但仍可能成功解析视频
                        resolve(true);
                    }
                };
                
                // 监听错误事件
                testFrame.onerror = () => {
                    clearTimeout(timeout);
                    reject(new Error('iframe加载失败'));
                };
            });
            
            // 如果测试成功，返回解析URL
            if (result) {
                console.log(`解析源 ${source.id} 测试通过，尝试播放`);
                // 清理测试iframe
                document.body.removeChild(testFrame);
                // 设置当前源索引，用于可能的后续切换
                currentSourceIndex = i;
                return fullUrl;
            }
        } catch (error) {
            console.log(`解析源 ${source.id} 测试失败:`, error.message);
            // 继续尝试下一个，不显示失败消息以减少视觉干扰
        }
    }
    
    // 清理测试iframe
    document.body.removeChild(testFrame);
    
    // 所有源都失败
    return null;
}

/**
 * 测试单个解析源
 * @param {string} sourceUrl 解析源URL
 * @param {string} videoUrl 视频URL
 * @returns {Promise<boolean>} 是否可用
 */
function testSource(sourceUrl, videoUrl) {
    return new Promise((resolve) => {
        const img = new Image();
        img.onload = () => resolve(true);
        img.onerror = () => resolve(false);
        img.src = sourceUrl + videoUrl;
    });
}

// 播放视频
function playVideo(url, sourceIndex = -1) {
    // 隐藏占位符，显示视频播放器
    videoPlaceholder.style.display = 'none';
    videoPlayer.style.display = 'block';
    
    // 使用iframe加载
    const iframe = document.createElement('iframe');
    iframe.id = 'video-iframe';
    iframe.src = url;
    iframe.frameBorder = '0';
    iframe.width = '100%';
    iframe.height = '100%';
    iframe.style.border = 'none';
    
    // 增强iframe属性确保视频可以播放
    iframe.allowFullscreen = true;
    iframe.allow = "accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share";
    iframe.setAttribute('allowFullScreen', '');
    iframe.setAttribute('webkitallowfullscreen', '');
    iframe.setAttribute('mozallowfullscreen', '');
    
    // 记录当前尝试的源索引
    if (sourceIndex >= 0) {
        currentSourceIndex = sourceIndex;
    }
    
    // 设置一个标志，用于检测是否真正加载了视频
    let videoLoaded = false;
    
    // 添加加载监听器
    iframe.onload = () => {
        console.log('视频iframe加载完成');
        videoLoaded = true;
        
        // 隐藏加载提示
        hideVideoCenterMessage();
        
        // 在iframe加载完成后，设置一个超时检测视频是否能正常播放
        setTimeout(() => {
            // 如果iframe内容为空或内容不符合预期，可能表示解析失败
            try {
                if (iframe.contentWindow.document.body.innerHTML.length < 100) {
                    handleVideoLoadFailure();
                }
            } catch (e) {
                // 跨域错误，无法直接检测，不做处理
                console.log('无法检测iframe内容，可能存在跨域限制');
            }
        }, 3000);
    };
    
    iframe.onerror = () => {
        console.error('视频iframe加载失败');
        handleVideoLoadFailure();
    };
    
    // 清空播放器内容
    videoPlayer.innerHTML = '';
    videoPlayer.appendChild(iframe);
    
    // 调试信息
    console.log('加载视频URL:', url);
    
    // 播放器出现动画
    animate(videoPlayer, {
        opacity: [0, 1],
        duration: 400,
        easing: 'easeOutCubic'
    });
    
    // 设置一个超时，如果视频在一定时间内没有加载完成，切换到下一个源
    setTimeout(() => {
        if (!videoLoaded && !isAutoSwitching) {
            handleVideoLoadFailure();
        }
    }, 10000);
}

// 隐藏中心消息 - 简化版本
function hideVideoCenterMessage() {
    if (videoCenterMessage.style.display === 'none') return;
    
    videoCenterMessage.style.transition = 'opacity 0.2s ease-in';
    videoCenterMessage.style.opacity = '0';
    
    setTimeout(() => {
        videoCenterMessage.style.display = 'none';
    }, 200);
}

// 处理视频加载失败，尝试下一个解析源
function handleVideoLoadFailure() {
    // 如果已经在处理自动切换，不要重复处理
    if (isAutoSwitching) return;
    
    isAutoSwitching = true;
    
    console.log('视频加载失败，尝试下一个解析源');
    
    // 获取可用的解析源数量（不包括自动选项）
    const sources = parseSources.filter(source => source.id !== 'auto');
    const totalSources = sources.length;
    
    // 尝试下一个解析源
    currentSourceIndex++;
    
    if (currentSourceIndex < sources.length) {
        // 还有可用的解析源
        const nextSource = sources[currentSourceIndex];
        const nextUrl = nextSource.url + currentVideoUrl;
        
        console.log(`自动切换到解析源 ${currentSourceIndex + 1}: ${nextSource.name}`);
        
        // 简化提示信息
        showVideoCenterMessage(`正在尝试解析源: ${nextSource.name}`, 99999, 'loading');
        
        // 延迟一点再加载下一个源，避免频繁切换
        setTimeout(() => {
            playVideo(nextUrl, currentSourceIndex);
            isAutoSwitching = false;
        }, 1000);
    } else {
        // 所有解析源都尝试过了
        console.log('所有解析源都失败了');
        
        // 简化最终错误消息
        showVideoCenterMessage('视频解析失败，请检查链接或稍后再试', 3000, 'error');
        
        setTimeout(() => {
            // 显示错误信息
            videoPlaceholder.style.display = 'flex';
            videoPlayer.style.display = 'none';
            
            videoPlaceholder.innerHTML = `
                <i class="bi bi-exclamation-circle"></i>
                <p>视频解析失败，请检查视频链接是否有效</p>
                <p style="font-size: 14px; opacity: 0.7; margin-top: 8px;">已尝试全部 ${totalSources} 个解析源</p>
            `;
            
            hideVideoCenterMessage();
            isAutoSwitching = false;
        }, 3000);
    }
}

// 视频解析函数
async function parseVideo() {
    const url = videoUrl.value.trim();
    currentVideoUrl = url;  // 保存用于后续自动切换解析源
    
    // 如果URL为空，直接在视频窗口中提示
    if (!url) {
        // 显示错误提示在视频窗口中
        videoPlaceholder.style.display = 'flex';
        videoPlayer.style.display = 'none';
        showVideoCenterMessage('请输入视频链接', 3000, 'error');
        
        // 添加输入框抖动效果
        animate(videoUrl, {
            translateX: [0, -5, 5, -5, 5, 0],
            duration: 400,
            easing: 'easeInOutQuad'
        });
        return;
    }
    
    // 检查URL是否有效，无效也在视频窗口提示
    if (!isValidUrl(url)) {
        videoPlaceholder.style.display = 'flex';
        videoPlayer.style.display = 'none';
        showVideoCenterMessage('请输入有效的URL地址', 3000, 'error');
        return;
    }
    
    // 重置自动切换状态
    isAutoSwitching = false;
    currentSourceIndex = -1;
    
    // 确保视频占位符可见，在播放前显示加载提示
    videoPlaceholder.style.display = 'flex';
    videoPlayer.style.display = 'none';
    
    // 显示视频窗口内的加载提示，使用加载类型
    showVideoCenterMessage('开始解析视频...', 99999, 'loading');
    
    // 保存当前选择的解析源
    currentSource = parseSource.value;
    
    try {
        let parsedUrl;
        
        // 根据选择的接口类型进行解析
        if (currentSource === 'auto') {
            // 自动模式：依次尝试所有接口
            parsedUrl = await autoTestSources(url);
        } else {
            // 指定接口：使用选定的接口
            const selectedSource = parseSources.find(s => s.id === currentSource);
            if (!selectedSource) {
                throw new Error('解析接口不存在');
            }
            parsedUrl = selectedSource.url + url;
            
            // 找出选定源的索引，用于后续可能的自动切换
            currentSourceIndex = parseSources.findIndex(s => s.id === currentSource) - 1;
            if (currentSourceIndex < 0) currentSourceIndex = 0;
            
            // 显示所选接口的解析信息，使用加载类型
            showVideoCenterMessage(`使用解析源: ${selectedSource.name}\n正在解析中...`, 99999, 'loading');
            
            // 模拟短暂延迟以提供更好的用户体验
            await new Promise(resolve => setTimeout(resolve, 1000));
        }
        
        if (!parsedUrl) {
            throw new Error('解析失败');
        }
        
        // 显示视频前先显示成功消息，使用成功类型
        showVideoCenterMessage('解析成功，开始播放', 1500, 'success');
        
        // 显示视频
        playVideo(parsedUrl, currentSourceIndex);
        
    } catch (error) {
        // 恢复视频占位符显示
        videoPlaceholder.style.display = 'flex';
        videoPlayer.style.display = 'none';
        
        // 显示自定义失败消息
        videoPlaceholder.innerHTML = `
            <i class="bi bi-exclamation-circle"></i>
            <p>正在尝试其他解析源...</p>
        `;
        
        // 显示警告消息，使用警告类型
        showVideoCenterMessage('解析失败，正在尝试其他解析源...', 1500, 'warning');
        
        // 自动尝试下一个解析源
        setTimeout(() => {
            if (!isAutoSwitching) {
                handleVideoLoadFailure();
            }
        }, 1500);
        
        console.error('解析错误:', error);
    } finally {
        // 恢复原来的解析源选择
        parseSource.value = currentSource;
    }
}

// 检查URL是否有效
function isValidUrl(url) {
    try {
        new URL(url);
        return true;
    } catch (error) {
        return false;
    }
} 